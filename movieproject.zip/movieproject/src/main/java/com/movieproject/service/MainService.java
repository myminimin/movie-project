package com.movieproject.service;



public interface MainService {
	
	
}
