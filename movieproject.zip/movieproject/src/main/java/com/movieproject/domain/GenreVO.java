package com.movieproject.domain;

public class GenreVO {
	private int genre_id;	  // movie_genre
	private String genre;	  	  // genre
	
}
