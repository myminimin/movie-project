package com.movieproject.domain;

public class DirectorVO {
	private int director_id;  // movie_director
	private String director_name; // director
}
