package com.movieproject.domain;

public class MovieVO {
	
	private String MemberID, content, image, Title;
	private int movie_id, ReleaseYear;
	
}
