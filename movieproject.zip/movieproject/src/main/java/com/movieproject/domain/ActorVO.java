package com.movieproject.domain;

public class ActorVO {
	private int actor_id;	  // movie_actor
	private String actor_name;	  // actor
	
}
