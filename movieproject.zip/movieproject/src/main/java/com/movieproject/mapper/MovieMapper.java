package com.movieproject.mapper;

import java.util.ArrayList;
import java.util.HashMap;

import com.movieproject.domain.MovieVO;

public interface MovieMapper {

	public MovieVO read(int movie_id);
	
	// public MovieVO joinread(int movie_id);
	
}
