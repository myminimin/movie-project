package com.movieproject.mapper;


public interface MainMapper {

	
	
}
